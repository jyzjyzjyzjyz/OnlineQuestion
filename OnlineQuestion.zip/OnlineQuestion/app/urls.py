"""OnlineQuestion URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
# from .views import *
from app import views

urlpatterns = [
    path('userlogin/', views.userlogin, name="userlogin"),
    path('userreg/', views.userreg, name="userreg"),
    path('adminlogin/', views.adminlogin, name="adminlogin"),
    path('adminreg/', views.adminreg, name="adminreg"),
    path('logout/', views.logout, name='logout'),
    path('user/<int:pIndex>', views.user, name='user'),
    path('useradd/', views.useradd, name='useradd'),
    path('useredit/<int:uid>', views.useredit, name='useredit'),
    path('userup/<int:uid>', views.userup, name='userup'),
    path('userdel/<int:uid>', views.userdel, name='userdel'),
    path('myedit/<int:uid>', views.myedit, name='myedit'),
    path('myup/<int:uid>', views.myup, name='myup'),
    path('admin/<int:pIndex>', views.admin, name='admin'),
    path('adminadd/', views.adminadd, name='adminadd'),
    path('adminedit/<int:uid>', views.adminedit, name='adminedit'),
    path('adminup/<int:uid>', views.adminup, name='adminup'),
    path('admindel/<int:uid>', views.admindel, name='admindel'),
    path('pay/<int:pIndex>', views.pay, name='pay'),
    path('payadd/', views.payadd, name='payadd'),
    path('breakindex/<int:pIndex>', views.breakindex, name='breakindex'),
    path('breakadd/', views.breakadd, name='breakadd'),
    path('breakdel/<int:uid>', views.breakdel, name='breakdel'),
    path('service/<int:pIndex>', views.service, name='service'),
    path('serviceup/<int:uid>', views.serviceup, name='serviceup'),
    path('servicedel/<int:uid>', views.servicedel, name='servicedel'),
    path('borrow/', views.borrow, name='borrow'),
    path('borrowadd/', views.borrowadd, name='borrowadd'),

]
