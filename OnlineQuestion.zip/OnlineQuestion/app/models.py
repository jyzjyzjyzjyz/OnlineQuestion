from django.db import models
from datetime import datetime


# Create your models here.

class User(models.Model):
    username = models.CharField(max_length=30, verbose_name="手机号")
    password = models.CharField(max_length=30, verbose_name="密码")
    paypassword = models.CharField(max_length=30, verbose_name="支付密码")
    name = models.CharField(max_length=30, verbose_name="姓名")
    usernumber = models.CharField(max_length=255, verbose_name="身份证号码")
    userphoto = models.CharField(max_length=255, verbose_name="身份证图片")
    moneyphoto = models.CharField(max_length=255, verbose_name="资产证明")
    banknumber = models.CharField(max_length=255, verbose_name="银行卡号")
    money = models.IntegerField(verbose_name="余额")

    def toDict(self):
        return {'id': self.id, 'username': self.username, 'paypassword': self.paypassword,
                'money': self.money, 'name': self.name}

    class Meta:
        db_table = "User"


class Admin(models.Model):
    username = models.CharField(max_length=30, verbose_name="姓名")
    password = models.CharField(max_length=30, verbose_name="密码")

    def toDict(self):
        return {'id': self.id, 'username': self.username}

    class Meta:
        db_table = "Admin"


class Pay(models.Model):
    banknumber = models.CharField(max_length=255, verbose_name="转账号")
    user = models.ForeignKey('User', on_delete=models.DO_NOTHING, related_name="payuser")
    getuser = models.ForeignKey('User', on_delete=models.DO_NOTHING, related_name="paygetuser")
    money = models.IntegerField(verbose_name="金额")
    paytime = models.DateTimeField(auto_now_add=True, verbose_name="转账时间")

    class Meta:
        db_table = "Pay"


class Loan(models.Model):
    banknumber = models.CharField(max_length=255, verbose_name="贷款号")
    user = models.ForeignKey('User', on_delete=models.DO_NOTHING, related_name="loatuser")
    money = models.CharField(max_length=30, verbose_name="贷款金额")
    time = models.CharField(max_length=30, verbose_name="贷款期限")
    sum = models.CharField(max_length=30, verbose_name="总金额")
    loantime = models.DateTimeField(auto_now_add=True, verbose_name="发起时间")
    state_choice = (
        (0, '待审批'),
        (1, '已通过'),
        (2, '不通过'),
    )
    state = models.SmallIntegerField(verbose_name="状态", choices=state_choice)

    def toDict(self):
        return {'id': self.id, 'state': self.state}

    class Meta:
        db_table = "Loan"
