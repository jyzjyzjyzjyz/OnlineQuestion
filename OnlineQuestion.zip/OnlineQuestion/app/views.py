from datetime import time

from django.http import HttpResponse
from django.shortcuts import render, redirect
from .models import User, Admin, Pay, Loan
from django.core.paginator import Paginator
from django.db.models import Q
from django.urls import reverse
import time
import json
from datetime import datetime
from django.utils.timezone import now, timedelta

import random


# Create your views here.


def userlogin(request):
    try:
        if request.method == "POST":
            username = request.POST.get("Lusername")
            password = request.POST.get("Lpass")
            obj = User.objects.filter(username=username).filter(password=password)
            user = User.objects.get(username=username)
            request.session['auth'] = user.toDict()
            request.session['admin'] = 0
            if not obj:
                return HttpResponse("登陆失败")
            else:
                return redirect('/pay/1')
        return render(request, 'userlogin.html')
    except Exception as err:
        print(err)
        context = {"Logininfo": "账号或密码错误"}
    return render(request, 'userlogin.html', context)


def userreg(request):
    if request.method == "GET":
        return render(request, 'userlogin.html')
    if request.method == "POST":
        username = request.POST.get("Rusername")
        password = request.POST.get("Rpass")
        paypassword = request.POST.get("Rpaypassword")
    if not username:
        context = {"Logininfo": "注册失败，不存在账号"}
        return render(request, 'userlogin.html', context)
    if not password:
        context = {"Logininfo": "注册失败，不存在密码"}
        return render(request, 'userlogin.html', context)
    else:
        banknumber = ""
        for i in range(10):
            banknumber += str(random.randint(0, 9))
        ob = User()
        ob.username = username
        ob.password = password
        ob.banknumber = banknumber
        ob.paypassword = paypassword
        ob.money = 0
        ob.save()
        context = {"Logininfo": "注册成功，请登录"}
    return render(request, 'userlogin.html', context)


def adminlogin(request):
    try:
        if request.method == "POST":
            print(request.POST)
            username = request.POST.get("Lusername")
            password = request.POST.get("Lpass")
            obj = Admin.objects.filter(username=username).filter(password=password)
            admin = Admin.objects.get(username=username)
            request.session['auth'] = admin.toDict()
            request.session['admin'] = 1
            if not obj:
                context = {"Logininfo": "账号或密码错误"}
                return render(request, 'adminlogin.html', context)
            else:
                return redirect('/user/1')
        return render(request, 'adminlogin.html')
    except Exception as err:
        print(err)
        context = {"Logininfo": "错误"}
    return render(request, 'adminlogin.html', context)


def adminreg(request):
    if request.method == "GET":
        return render(request, 'adminlogin.html')
    if request.method == "POST":
        username = request.POST.get("Rusername")
        password = request.POST.get("Rpass")
    if not username:
        context = {"Logininfo": "注册失败，不存在账号"}
        return render(request, 'adminlogin.html', context)
    if not password:
        context = {"Logininfo": "注册失败，不存在密码"}
        return render(request, 'adminlogin.html', context)
    else:
        ob = Admin()
        ob.username = username
        ob.password = password
        ob.save()
        context = {"Logininfo": "注册成功，请登录"}
    return render(request, 'adminlogin.html', context)


def logout(request):
    del request.session['admin']
    del request.session['auth']
    return redirect("userlogin")


def user(request, pIndex=1):
    rou = 'user'
    ulist = User.objects.all()
    mywhere = []
    kw = request.GET.get("keyword", None)
    if kw:
        ulist = ulist.filter(Q(username__contains=kw))
        mywhere.append('keyword=' + kw)
    pIndex = int(pIndex)
    page = Paginator(ulist, 10)
    maxpages = page.num_pages
    if pIndex > maxpages:
        pIndex = maxpages
    if pIndex < 1:
        pIndex = 1
    list = page.page(pIndex)
    plist = page.page_range
    context = {"list": list, 'plist': plist, 'pIndex': pIndex, 'maxpages': maxpages, 'mywhere': mywhere,
               'rou': rou, }
    return render(request, "project/user/user.html", context)


def useradd(request):
    if request.method == "GET":
        return render(request, 'project/user/useradd.html')
    if request.method == "POST":
        getdata = request.POST.get("name")
        getdata2 = request.POST.get("name2")
        getdata3 = request.POST.get("name3")
        myfile = request.FILES.get("picpath", None)
        if myfile:
            cover_pic = str(time.time()) + "." + myfile.name.split('.').pop()
            destination = open("./app/static/uploads/" + cover_pic, "wb+")
            print(destination)
            for chunk in myfile.chunks():
                destination.write(chunk)
            destination.close()
        myfile1 = request.FILES.get("picpath1", None)
        if myfile1:
            cover_pic1 = str(time.time()) + "." + myfile1.name.split('.').pop()
            destination = open("./app/static/uploads/" + cover_pic1, "wb+")
            for chunk in myfile1.chunks():
                destination.write(chunk)
            destination.close()

        if not getdata:
            context = {"info": "请重新输入"}
            return render(request, 'project/student/useradd.html', context)
        xt = User.objects.filter(username=getdata)
        if xt:
            context = {"info": "账号已存在"}
            return render(request, 'project/student/useradd.html', context)
        else:
            ob = User()
            ob.username = getdata
            ob.password = getdata2
            ob.paypassword = getdata3
            ob.usernumber = request.POST.get("name4")
            ob.userphoto = cover_pic
            ob.moneyphoto = cover_pic1
            banknumber = ""
            for i in range(10):
                banknumber += str(random.randint(0, 9))
            ob.banknumber = banknumber
            ob.money = 0
            ob.save()
    return redirect(reverse("user", args=(1,)))


def userdel(request, uid=0):
    User.objects.get(id=uid).delete()
    return redirect(reverse("user", args=(1,)))


def useredit(request, uid=0):
    try:
        ob = User.objects.get(id=uid)
        context = {'data': ob}
        return render(request, "project/user/useredit.html", context)
    except Exception as err:
        print(err)
        return redirect(reverse("user", args=(1,)))


def userup(request, uid=0):
    try:
        print(request.POST)
        ob = User.objects.get(id=uid)
        myfile = request.FILES.get("picpath", None)
        if myfile:
            cover_pic = str(time.time()) + "." + myfile.name.split('.').pop()
            destination = open("./app/static/uploads/" + cover_pic, "wb+")
            for chunk in myfile.chunks():
                destination.write(chunk)
            destination.close()
            ob.userphoto = cover_pic
        myfile1 = request.FILES.get("picpath1", None)
        if myfile1:
            cover_pic = str(time.time()) + "." + myfile1.name.split('.').pop()
            destination = open("./app/static/uploads/" + cover_pic, "wb+")
            for chunk in myfile1.chunks():
                destination.write(chunk)
            destination.close()
            ob.moneyphoto = cover_pic
        ob.username = request.POST['name']
        ob.password = request.POST['name2']
        ob.paypassword = request.POST['name3']
        ob.usernumber = request.POST['name4']
        ob.money = request.POST['name5']
        ob.banknumber = request.POST['name6']
        ob.save()
    except Exception as err:
        print(err)
    return redirect(reverse("user", args=(1,)))


def myedit(request, uid=0):
    try:
        ob = User.objects.get(id=uid)
        context = {'data': ob}
        return render(request, "project/user/myedit.html", context)
    except Exception as err:
        print(err)
        return redirect(reverse("pay", args=(1,)))


def myup(request, uid=0):
    try:
        print(request.POST)
        ob = User.objects.get(id=uid)
        myfile = request.FILES.get("picpath", None)
        myfile1 = request.FILES.get("picpath1", None)
        if (len(request.POST['name3']) != 6):
            context = {"info": "支付密码为六位", 'data': ob}
            return render(request, "project/user/myedit.html", context)
        else:
            if myfile:
                cover_pic = str(time.time()) + "." + myfile.name.split('.').pop()
                destination = open("./app/static/uploads/" + cover_pic, "wb+")
                for chunk in myfile.chunks():
                    destination.write(chunk)
                destination.close()
                ob.userphoto = cover_pic
            if myfile1:
                cover_pic = str(time.time()) + "." + myfile1.name.split('.').pop()
                destination = open("./app/static/uploads/" + cover_pic, "wb+")
                for chunk in myfile1.chunks():
                    destination.write(chunk)
                destination.close()
                ob.moneyphoto = cover_pic
            if request.POST['name']:
                ob.username = request.POST['name']
            if request.POST['name2']:
                ob.password = request.POST['name2']
            if request.POST['name3']:
                ob.paypassword = request.POST['name3']
            if request.POST['name4']:
                ob.usernumber = request.POST['name4']
            ob.save()
    except Exception as err:
        print(err)
    return redirect(reverse("pay", args=(1,)))


def admin(request, pIndex=1):
    rou = 'admin'
    ulist = Admin.objects.all()
    mywhere = []
    kw = request.GET.get("keyword", None)
    if kw:
        ulist = ulist.filter(Q(username__contains=kw))
        mywhere.append('keyword=' + kw)
    pIndex = int(pIndex)
    page = Paginator(ulist, 10)
    maxpages = page.num_pages
    if pIndex > maxpages:
        pIndex = maxpages
    if pIndex < 1:
        pIndex = 1
    list = page.page(pIndex)
    plist = page.page_range
    context = {"list": list, 'plist': plist, 'pIndex': pIndex, 'maxpages': maxpages, 'mywhere': mywhere,
               'rou': rou, }
    return render(request, "project/admin/admin.html", context)


def adminadd(request):
    if request.method == "GET":
        return render(request, 'project/admin/adminadd.html')
    if request.method == "POST":
        getdata = request.POST.get("name")
        getdata2 = request.POST.get("name2")
        if not getdata:
            context = {"info": "请重新输入"}
            return render(request, 'project/admin/adminadd.html', context)
        xt = Admin.objects.filter(username=getdata)
        if xt:
            context = {"info": "管理员账号已存在"}
            return render(request, 'project/admin/adminadd.html', context)
        else:
            ob = Admin()
            ob.username = getdata
            ob.password = getdata2
            ob.save()
    return redirect(reverse("admin", args=(1,)))


def admindel(request, uid=0):
    Admin.objects.get(id=uid).delete()
    return redirect(reverse("admin", args=(1,)))


def adminedit(request, uid=0):
    try:
        ob = Admin.objects.get(id=uid)
        context = {'data': ob}
        return render(request, "project/admin/adminedit.html", context)
    except Exception as err:
        print(err)
        return redirect(reverse("admin", args=(1,)))


def adminup(request, uid=0):
    try:
        ob = Admin.objects.get(id=uid)
        ob.username = request.POST['name']
        ob.password = request.POST['name2']
        ob.save()
    except Exception as err:
        print(err)
    return redirect(reverse("admin", args=(1,)))


def pay(request, pIndex=1):
    rou = 'pay'
    ulist = Pay.objects.all()
    mywhere = []
    kw = request.GET.get("keyword", None)
    if kw:
        ulist = ulist.filter(Q(banknumber__contains=kw))
        mywhere.append('keyword=' + kw)
    pIndex = int(pIndex)
    page = Paginator(ulist, 10)
    maxpages = page.num_pages
    if pIndex > maxpages:
        pIndex = maxpages
    if pIndex < 1:
        pIndex = 1
    list = page.page(pIndex)
    plist = page.page_range
    context = {"list": list, 'plist': plist, 'pIndex': pIndex, 'maxpages': maxpages, 'mywhere': mywhere,
               'rou': rou, }
    return render(request, "project/pay/pay.html", context)


def payadd(request):
    if request.method == "GET":
        uid = request.session['auth'].get('id')
        vo = User.objects.get(id=uid)
        request.session['auth'] = vo.toDict()
        if (vo.paypassword != "" or vo.usernumber != ""):
            rou = 'payadd'
            ulist = User.objects.all().exclude(id=request.session['auth'].get('id'))
            context = {"list": ulist, "rou": rou}
            return render(request, 'project/pay/payadd.html', context)
        else:
            ulist = User.objects.all().exclude(id=request.session['auth'].get('id'))
            context = {"list": ulist, "info": "支付密码或身份证为空,无法转账,请设置支付密码"}
            return render(request, 'project/err.html', context)
    if request.method == "POST":
        user = request.POST.get("user")
        getdata = request.POST.get("name")
        paypassword = request.POST.get("paypassword")
        ulist = User.objects.all().exclude(id=request.session['auth'].get('id'))
        if not (user and getdata):
            context = {"list": ulist, "info": "信息未完整"}
            return render(request, 'project/pay/payadd.html', context)
        else:
            vo = User.objects.get(id=request.session['auth'].get('id'))
            if (vo.paypassword == paypassword):
                if (vo.money > int(getdata)):
                    vo.money = vo.money - int(getdata)
                    vo.save()
                    banknumber = ""
                    for i in range(10):
                        banknumber += str(random.randint(0, 9))
                    ob = Pay()
                    ob.banknumber = banknumber
                    ob.user_id = request.session['auth'].get('id')
                    ob.getuser_id = user
                    ob.money = int(getdata)
                    ob.save()
                    vo = User.objects.get(id=user)
                    vo.money = vo.money + int(getdata)
                    vo.save()

                    uid = request.session['auth'].get('id')
                    vo = User.objects.get(id=uid)
                    request.session['auth'] = vo.toDict()

                    resp = {"status": "0", "data": "转账成功"}
                    return HttpResponse(json.dumps(resp), content_type="application/json")
                else:
                    context = {"list": ulist, "info": "余额不足"}
                    return render(request, 'project/pay/payadd.html', context)
            else:
                context = {"list": ulist, "info": "支付密码错误"}
                return render(request, 'project/pay/payadd.html', context)


def breakindex(request, pIndex=1):
    rou = 'breakindex'
    ulist = Loan.objects.all()
    mywhere = []
    kw = request.GET.get("keyword", None)
    if kw:
        ulist = ulist.filter(Q(banknumber__contains=kw))
        mywhere.append('keyword=' + kw)
    pIndex = int(pIndex)
    page = Paginator(ulist, 10)
    maxpages = page.num_pages
    if pIndex > maxpages:
        pIndex = maxpages
    if pIndex < 1:
        pIndex = 1
    list = page.page(pIndex)
    plist = page.page_range
    context = {"list": list, 'plist': plist, 'pIndex': pIndex, 'maxpages': maxpages, 'mywhere': mywhere,
               'rou': rou, }
    return render(request, "project/break/break.html", context)


def breakadd(request):
    if request.method == "GET":
        rou = "breakadd"
        context = {"rou": rou}
        return render(request, 'project/break/breakadd.html', context)
    if request.method == "POST":
        user = request.session['auth'].get('id')
        print(request.POST)
        getdata2 = request.POST.get("name2")
        time = request.POST.get("time")
        sum = request.POST.get("sum")
        if not (getdata2 or time or sum):
            context = {"info": "信息未完整"}
            return render(request, 'project/break/breakadd.html', context)
        else:
            ob = Loan()
            banknumber = ""
            for i in range(10):
                banknumber += str(random.randint(0, 9))
            ob.banknumber = banknumber
            ob.user_id = user
            ob.money = getdata2
            ob.time = time
            ob.sum = sum
            ob.state = 0
            ob.save()
    return redirect(reverse("breakindex", args=(1,)))


def breakdel(request, uid=0):
    Loan.objects.get(id=uid).delete()
    return redirect(reverse("breakindex", args=(1,)))


def service(request, pIndex=1):
    rou = 'service'
    ulist = Loan.objects.all()
    mywhere = []
    kw = request.GET.get("keyword", None)
    if kw:
        ulist = ulist.filter(Q(room__contains=kw))
        mywhere.append('keyword=' + kw)
    pIndex = int(pIndex)
    page = Paginator(ulist, 10)
    maxpages = page.num_pages
    if pIndex > maxpages:
        pIndex = maxpages
    if pIndex < 1:
        pIndex = 1
    list = page.page(pIndex)
    plist = page.page_range
    context = {"list": list, 'plist': plist, 'pIndex': pIndex, 'maxpages': maxpages, 'mywhere': mywhere,
               'rou': rou, }
    return render(request, "project/service/service.html", context)


def servicedel(request, uid=0):
    try:
        ob = Loan.objects.get(id=uid)
        ob.state = 2
        ob.save()
    except Exception as err:
        print(err)
    return redirect(reverse("service", args=(1,)))


def serviceup(request, uid=0):
    try:
        ob = Loan.objects.get(id=uid)
        ob.state = 1
        ob.save()
        user = User.objects.get(id=ob.user.id)
        user.money = int(user.money) + int(ob.money)
        user.save()
    except Exception as err:
        print(err)
    return redirect(reverse("service", args=(1,)))


def borrow(request, pIndex=1):
    rou = 'borrow'
    context = {
        'rou': rou, }
    return render(request, "project/borrow/borrow.html", context)


def borrowadd(request):
    rou = 'borrowadd'
    context = {
        'rou': rou, }
    return render(request, "project/borrow/borrowadd.html", context)
